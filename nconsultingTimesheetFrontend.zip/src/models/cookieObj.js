export const cookieObj = {
  token: '',
  isLoggedIn: '',
  email: '',
  role: '',
  isDefaultPasswordChanged: '',
  firstName: '',
  lastName: '',
  employeeId: '',
  location: '',
};
