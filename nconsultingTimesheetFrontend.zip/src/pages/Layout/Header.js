import React, { useState, useRef, useEffect } from "react";
import { Button, Menu, MenuItem, ListItemIcon, Box, Typography, Divider } from "@mui/material";
import { UserCircle, User, Key } from "lucide-react";
import { makeStyles } from "@mui/styles";
import { getCookie, setCookie } from "../../services/Cookies";
import PasswordChange from "../../services/PasswordChange";
import { useNavigate } from "react-router-dom";
import { postRequest } from "../../services/Apiservice";
import LoadingMask from "../../services/LoadingMask";
import { ToastError, ToastSuccess } from "../../services/ToastMsg";

const useStyles = makeStyles({
  button: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: "2px",
    width: "100%",
    padding: "6px 10px",
  },
  dateText: {
    fontSize: "12px",
    fontWeight: "bold",
  },
  timerText: {
    fontSize: "14px",
    fontWeight: "bold",
  },
});

const Header = () => {
  const classes = useStyles();
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(getCookie("isDefaultPasswordChanged") === "false");
  const [isManualChange, setIsManualChange] = useState(false); // true when user clicks menu

  // Get user details from cookies
  const firstName = getCookie("firstName") || "";
  const lastName = getCookie("lastName") || "";
  const employeeId = getCookie("employeeId") || "";

  // Account menu handlers
  const handleAccountClick = (event) => setAnchorEl(event.currentTarget);
  const handleAccountClose = () => setAnchorEl(null);

  // When user clicks "Change Password" in menu
  const handleManualPasswordChange = () => {
    setIsManualChange(true);
    setShowPassword(true);
    handleAccountClose();
  };

  return (
    <header className="header">
      <LoadingMask loading={loading} />
      {/* PasswordChange modal */}
      {showPassword && (
        <PasswordChange
          isManualChange={isManualChange}
          onSuccess={() => {
            setShowPassword(false);
            setIsManualChange(false);
          }}
          onClose={() => {
            setShowPassword(false);
            setIsManualChange(false);
          }}
        />
      )}

      <div className="header-left">
        <img src="/assets/images/natobotics-logo.png" alt="Logo" className="header-logo" />
        <div className="header-text">
          N-Consulting
        </div>
      </div>

      <div className="header-right">

        {/* Account icon */}
        <div className="icon-with-text" onClick={handleAccountClick} style={{ cursor: "pointer", marginLeft: 10 }}>
          <UserCircle size={25} />
          <span>Account</span>
        </div>

        {/* Account Menu */}
        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleAccountClose}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
          transformOrigin={{ vertical: "top", horizontal: "right" }}
        >
          <Box sx={{ px: 2, py: 1 }}>
            <Typography variant="subtitle1" color="textSecondary">
              Hi,
            </Typography>
            <Typography variant="body1" fontWeight="bold">
              {firstName} {lastName}
            </Typography>
            <Typography variant="body3" color="textSecondary">
              {employeeId}
            </Typography>
          </Box>
          <Divider />
          <MenuItem onClick={() => { handleAccountClose(); navigate("/view-employee") }}>
            <ListItemIcon>
              <User size={18} />
            </ListItemIcon>
            View Profile
          </MenuItem>
          <MenuItem onClick={handleManualPasswordChange}>
            <ListItemIcon>
              <Key size={18} />
            </ListItemIcon>
            Change Password
          </MenuItem>
        </Menu>
      </div>
    </header>
  );
};

export default Header;
