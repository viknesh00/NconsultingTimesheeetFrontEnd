import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Box, TextField, Button, Typography } from "@mui/material";
import { LocalizationProvider, TimePicker } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { format, parse } from "date-fns";
import { makeStyles } from "@mui/styles";
import Autocomplete from "@mui/material/Autocomplete";
import { postRequest } from "../../services/Apiservice";
import { ToastError, ToastSuccess } from "../../services/ToastMsg";
import LoadingMask from "../../services/LoadingMask";
import Breadcrumb from "../../services/BreadCrumb";

const useStyles = makeStyles({
  rootBox: {
    backgroundColor: "#f9f9f9",
    padding: 24,
    borderRadius: 12,
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
  },
  container: {
    maxWidth: 500,
    margin: "50px auto",
    padding: 24,
    display: "flex",
    flexDirection: "column",
    gap: 24,
  },
  title: {
    textAlign: "center",
    fontWeight: 600,
    fontSize: 22,
    marginBottom: 16,
  },
  buttonsContainer: {
    display: "flex",
    justifyContent: "center",
    gap: 16,
    marginTop: 24,
  },
});

const DepartmentForm = () => {
  const classes = useStyles();
  const navigate = useNavigate();
  const location = useLocation();
  const editData = location.state?.editData || null;
  const breadCrumb = [
    { label: "Department", link: "/department" },
    { label: editData ? "Edit-Department" : "Create-Department" }
  ];

  const [loading, setLoading] = useState(false);
  const countries = [
    { label: "All", value: "All" },
    { label: "India", value: "India" },
    { label: "UK", value: "UK" },
    { label: "USA", value: "USA" },
    { label: "Singapore", value: "Singapore" },
    { label: "Germany", value: "Germany" },
    { label: "NetherLands", value: "NetherLands" },
    { label: "Poland", value: "Poland" },
    { label: "Australia", value: "Australia" },
    { label: "Spain", value: "Spain" },
    { label: "Dubai", value: "Dubai" },
  ];
  const [formValues, setFormValues] = useState({
    deptId: editData?.deptId ?? null,
    departmentName: editData?.departmentName
      ? editData.departmentName
      : null,
    location: editData.location.split(",").map(c => countries.find(x => x.value === c)),
    startTime: editData?.startTime ? parse(editData.startTime, "HH:mm:ss", new Date()) : null,
    endTime: editData?.endTime ? parse(editData.endTime, "HH:mm:ss", new Date()) : null,
  });


  const handleSave = () => {
    if (!formValues.location.length === 0) {
      ToastError(`Please fill all mandatory fields`);
      return;
    }
    const saveData = {
      ...formValues,
      deptId: formValues.deptId,
      startTime: formValues.startTime ? format(formValues.startTime, "HH:mm:ss") : null,
      endTime: formValues.endTime ? format(formValues.endTime, "HH:mm:ss") : null,
      departmentName: formValues.departmentName || "",
      location: formValues.location.map(c => c.value).join(",")
    };

    setLoading(true);
    const url = `Department/InsertOrUpdateDepartment`;
    postRequest(url, saveData)
      .then((res) => {
        if (res.status === 200) {
          ToastSuccess(res.data.message);
          navigate("/department");
        }
      })
      .catch((err) => {
        setLoading(false);
        console.error(err);
      });
  };

  const handleCancel = () => navigate("/attendance/working-hours");

  return (
    <Box className={classes.rootBox}>
      <LoadingMask loading={loading} />
      <Breadcrumb items={breadCrumb} />
      <Box className={classes.container}>
        <Typography variant="h6" className={classes.title}>
          {editData ? "Edit Department" : "Create Department"}
        </Typography>

        <TextField
          label="Department Name"
          fullWidth
          value={formValues.departmentName || ""}
          onChange={(e) =>
            setFormValues({ ...formValues, departmentName: e.target.value })
          }
        />

        <Autocomplete
          multiple
          options={countries}
          getOptionLabel={(o) => o.label}
          value={formValues.location}
          onChange={(event, newValue, reason, details) => {
    // trust newValue (it already reflects add/remove),
    // but we still enforce the "All" rules and dedupe by value.
    let selected = Array.isArray(newValue) ? [...newValue] : [];

    const clicked = details?.option;

    if (clicked?.value === "All") {
      // Toggle All: if it was selected previously, user is removing it
      const alreadySelected = formValues.location.some(i => i.value === "All");
      selected = alreadySelected ? [] : [{ label: "All", value: "All" }];
    } else {
      // Normal country clicked: remove "All" if present
      selected = selected.filter(item => item.value !== "All");
    }

    // Final safeguard: dedupe by value
    selected = selected.filter((item, idx, arr) =>
      arr.findIndex(a => a.value === item.value) === idx
    );

    setFormValues(prev => ({
      ...prev,
      location: selected
    }));
  }}
          renderInput={(params) => <TextField {...params} label={<span>Work Location <span style={{ color: 'red' }}>*</span></span>} fullWidth />}
        />



        {/* Start Time */}
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <TimePicker
            label="Start Time"
            value={formValues.startTime}
            onChange={(newValue) =>
              setFormValues({ ...formValues, startTime: newValue })
            }
            renderInput={(params) => <TextField {...params} fullWidth />}
          />
        </LocalizationProvider>

        {/* End Time */}
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <TimePicker
            label="End Time"
            value={formValues.endTime}
            onChange={(newValue) =>
              setFormValues({ ...formValues, endTime: newValue })
            }
            renderInput={(params) => <TextField {...params} fullWidth />}
          />
        </LocalizationProvider>

        {/* Buttons */}
        <Box className={classes.buttonsContainer}>
          <Button variant="contained" onClick={handleSave}>
            Save
          </Button>
          <Button variant="outlined" onClick={handleCancel}>
            Cancel
          </Button>
        </Box>
      </Box>
    </Box>
  );
};

export default DepartmentForm;